from sklearn.tree import DecisionTreeClassifier # Import Decision Tree Classifier
from sklearn.model_selection import train_test_split # Import train_test_split function
from sklearn import metrics
res=[]
y=[]
path=r"C:\Users\soura\OneDrive\Desktop\chatbot\intelligent_chatbot\chatbot\vader_lexicon.txt"
with open(path) as f:
    lines = f.readlines()

    
    for i in lines:
        ii=i.replace("\n","").split('\t')
        
        t=ii[3].replace('[',"").replace(']',"").split(",")
        tt=[]
        for j in t:
            tt.append(float(j))
        res.append(tt)
        
        if float(ii[2])>0:
            y.append(1)
        else:
            y.append(0)
print(res[0])
print(res[1])

X_train, X_test, y_train, y_test = train_test_split(res, y, test_size=0.3, random_state=1)

clf = DecisionTreeClassifier()

# Train Decision Tree Classifer
clf = clf.fit(X_train,y_train)

#Predict the response for test dataset
y_pred = clf.predict(X_test)

print("Accuracy:",metrics.accuracy_score(y_test, y_pred))

import joblib
jlib_file = "dt_Model.pkl"
joblib.dump(clf,jlib_file)

Joblib_dt = joblib.load(jlib_file)